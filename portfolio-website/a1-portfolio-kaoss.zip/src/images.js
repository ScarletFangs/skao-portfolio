const NavIcons = 
{
    HomeIcon: '../src/assets/NavIcons/house.svg',
    ProfileIcon: '../src/assets/NavIcons/profile.svg',
    ProjectIcon: '../src/assets/NavIcons/projects.svg',
    SelfPic: '../src/assets/NavIcons/selfpic.jpg'
};

export default NavIcons;